from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler, TeamDatabaseHandler
import random
import json


class TeamPremadeChatMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        pass
        
    def decode(self):
        fields = {}
        fields["Unk1"] = self.readVInt()
        fields["MessageDataID"] = self.readVInt()
        fields["Unk"] = self.readVInt()
        fields["Unk"] = self.readVInt()
        fields["EmoteID"] = self.readVInt()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        teamdb_instance = TeamDatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(calling_instance.player.TeamID[1])[0][1])
        
        LastMessageID = len(teamData["ChatData"])
        Role = int(teamData["Members"][str(playerData["ID"][1])]["Owner"])
        message = {
        'StreamType': 8,
        'StreamID': [0, LastMessageID + 1],
        'PlayerID': calling_instance.player.ID,
        'PlayerName': calling_instance.player.Name,
        'PlayerRole': Role,
        'MessageDataID': fields["MessageDataID"],
        'PremadeID': fields["EmoteID"]
        }
        teamData["ChatData"].append(message)
        print(calling_instance.player)
        teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        allSockets = ClientsManager.GetAll()
        for x in teamData["Members"]:
        	if int(x) in allSockets:
        		fields["Socket"] = allSockets[int(x)]["Socket"]
        		Messaging.sendMessage(24131, fields, calling_instance.player)
        

    def getMessageType(self):
        return 14369

    def getMessageVersion(self):
        return self.messageVersion