from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.Messaging import Messaging
from Static.StaticData import StaticData
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
from Classes.Instances.Classes.Team import Team
from Classes.Utility import Utility
import json


class TeamSetMemberReadyMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        pass

    def decode(self):
        fields = {}
        fields["Ready"] = self.readVInt()
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        teamdb_instance = TeamDatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(calling_instance.player.TeamID[1])[0][1])
        teamData["Members"][str(calling_instance.player.ID[1])]["Ready"] = bool(fields["Ready"])
        teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        allSockets = ClientsManager.GetAll()
        allmembers = len(teamData["Members"])
        Readys = []
        for x in teamData["Members"]:
        	fields["Socket"] = allSockets[int(x)]["Socket"]
        	Messaging.sendMessage(24124, fields, calling_instance.player)
        	Readys.append(teamData["Members"][x]["Ready"])
        	if len(Readys) == allmembers:
        		if not False in Readys:
        			Messaging.sendMessage(24130, fields, calling_instance.player)
        			Messaging.sendMessage(20405, fields, calling_instance.player)
        			Messaging.sendMessage(24112, fields, calling_instance.player)
        			Messaging.sendMessage(20559, fields, calling_instance.player)
        			Messaging.sendMessage(24112, fields, calling_instance.player)
        			tick = 1
        			fields["Tick"] = tick
        			Messaging.sendMessage(24109, fields, calling_instance.player)


    def getMessageType(self):
        return 14355


    def getMessageVersion(self):
        return self.messageVersion
