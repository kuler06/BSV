from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Wrappers.AllianceHeaderEntry import AllianceHeaderEntry
from Database.DatabaseHandler import ClubDatabaseHandler, DatabaseHandler
from Classes.ClientsManager import ClientsManager
import json

class AllianceTeamsMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        clubdb_instance = ClubDatabaseHandler()
        db_instance = DatabaseHandler()
        clubData = json.loads(clubdb_instance.getClubWithLowID(player.AllianceID[1])[0][1])
        db_instance.loadAccount(player, player.ID)
        allSockets = ClientsManager.GetAll()

        self.writeVInt(1)

        self.writeVInt(1) #Count

        for i in range(1):
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeLong(17, 82357820) #???ID
            self.writeVInt(0)
            self.writeVLong(0,0) # hz
            self.writeVLong(0,0) # hz
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(2)
            for x in range(2):
            	self.writeVLong(8, 43928836) # PlayerID
            	self.writeVInt(0)
            	self.writeVInt(0)
            	self.writeVInt(0)
            self.writeDataReference(0, 0) # pizdec
            self.writeVInt(0)
            self.writeBoolean(False)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24364

    def getMessageVersion(self):
        return self.messageVersion
