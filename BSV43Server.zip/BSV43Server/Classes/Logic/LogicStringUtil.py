class LogicStringUtil:
    @staticmethod
    def getBytes(string):
        return string.encode()

    @staticmethod
    def getByteLength(string):
        return len(string)
