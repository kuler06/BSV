from Classes.ByteStream import ByteStream
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters
import json
import random


class LogicClaimTailRewardCommand(LogicCommand):
    
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["Unk1"] = calling_instance.readVInt()
        fields["Unk2"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
    	pass

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        player_data["delivery_items"] = {
        'Boxes': []
        }
        box = {
        'Type': 0,
        'Items': []
        }
        brawlers= list(player_data["OwnedBrawlers"].keys())
        pp1= random.randint(9,127)
        pp2 = random.randint(9,127)
        pp3 = random.randint(9,127)
        ppbr = random.randint(20, 64)
        brawlerID1= random.choice(brawlers)
        brawlerID2 = random.choice(brawlers)
        brawlerID3 = random.choice(brawlers)
        while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        	brawlerID2 = random.choice(brawlers)
        while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        	brawlerID3 = random.choice(brawlers)
        if len(brawlers) != len(Characters.getBrawlersID()):
        	brawlerID6 = random.randint(0, 59)
        	while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        		brawlerID6 = random.randint(0, 59)
        gold = random.randint(21, 134)
        if random.randint(0, 10) == 7:
        	gems = random.randint(30, 90)
        elif random.randint(0, 5) == 2:
        	gems = random.randint(20, 50)
        else:
        	gems = random.randint(5, 30)
        box['Type'] = 12
        item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        box['Items'].append(item)
        item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        box['Items'].append(item)
        item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        box['Items'].append(item)
        item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        box['Items'].append(item)
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID1):
        				v["PowerPoints"] += pp1
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID2):
        				v["PowerPoints"] += pp2
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID3):
        				v["PowerPoints"] += pp3
        if random.randint(0, 10) == 3:
            if len(brawlers) != len(Characters.getBrawlersID()):
            	item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
            	box['Items'].append(item)
            	player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        else:
             if random.randint(0, 6) == 2:
             	item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
             	box['Items'].append(item)
        if random.randint(0, 3) == 2:
        	       item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        	       box['Items'].append(item)
        player_data["Gems"] += gems
        if player_data["BPTokens"] >= 500:
        	player_data["BPTokens"] -= 500
        	player_data["delivery_items"]['Boxes'].append(box)
        	
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields)


    def getCommandType(self):
        return 535


