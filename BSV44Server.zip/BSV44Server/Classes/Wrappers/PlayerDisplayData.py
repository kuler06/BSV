from Database.DatabaseHandler import DatabaseHandler
import json


class PlayerDisplayData:
    def encode(calling_instance, playerData):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(playerData['ID'])[2])
        
        calling_instance.writeString(playerData["Name"])
        calling_instance.writeVInt(100)
        calling_instance.writeVInt(28000000 + playerData["Thumbnail"])
        calling_instance.writeVInt(43000000 + playerData["Namecolor"])
        try:
        	playerData["BPActivated"]
        except KeyError:
        	playerData["BPActivated"] = False
        if playerData["BPActivated"]:
        	calling_instance.writeVInt(46000000 + playerData["Namecolor"])
        else:
        	calling_instance.writeVInt(-1)

    def decode(calling_instance, fields):
        fields["PlayerDisplayData"] = {}
        fields["PlayerDisplayData"]["Name"] = calling_instance.readString()
        fields["PlayerDisplayData"]["Unknown"] = calling_instance.readVInt()
        fields["PlayerDisplayData"]["Thumbnail"] = calling_instance.readVInt()
        fields["PlayerDisplayData"]["Namecolor"] = calling_instance.readVInt()
        fields["PlayerDisplayData"]["Unknown"] = calling_instance.readVInt()