from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import ClubDatabaseHandler, TeamDatabaseHandler
from Classes.Stream.StreamEntryFactory import StreamEntryFactory
import json


class TeamStreamMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        teamdb_instance = TeamDatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(player.TeamID[1])[0][1])
        
        self.writeVLong(teamData["HighID"], teamData["LowID"]) # TeamID
        self.writeVInt(1)
        StreamID = len(teamData["ChatData"])
        for i in teamData['ChatData']:
            if i['StreamID'][1] == StreamID:
            	self.writeVInt(i['StreamType'])
            	StreamEntryFactory.encode(self, fields, i)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24124, fields, calling_instance.player)

    def getMessageType(self):
        return 24131

    def getMessageVersion(self):
        return self.messageVersion