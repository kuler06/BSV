from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
import json


class TeamMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        teamdb_instance = TeamDatabaseHandler()
        db_instance = DatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(player.TeamID[1])[0][1])
        
        self.writeVInt(teamData['Type']) # Room Type
        self.writeBoolean(teamData["Type"] == 1)
        self.writeVInt(0)

        self.writeLong(teamData["HighID"], teamData["LowID"]) # TeamID

        self.writeVInt(0)
        
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeDataReference(15, teamData["mapID"]) # Map
        
        self.writeBoolean(False) # BattlePlayerMap
        
        self.writeVInt(len(teamData["Members"]))  # Players Array
        for x in teamData["Members"]:
        	memberData = teamData["Members"][x]
        	playerData = json.loads(db_instance.getPlayerEntry([memberData['HighID'], memberData['LowID']])[2])
        	self.writeBoolean(memberData["Owner"])  # Owner
        	self.writeLong(playerData["ID"][0], playerData["ID"][1]) # Player ID
        	self.writeDataReference(16, playerData["SelectedBrawlers"][0]) # Brawler
        	try:
        		SkinID = playerData["BrawlersSelectedSkins"][str(playerData["SelectedBrawlers"][0])]
        	except KeyError:
        		SkinID = 0
        	if SkinID != 0:
        		self.writeDataReference(29, SkinID) # Brawler Skin
        	else:
        		self.writeDataReference(0, 0) # Brawler Skin
        	self.writeVInt(0) # ?
        	self.writeVInt(player.OwnedBrawlers[str(playerData["SelectedBrawlers"][0])]['Trophies']) # Brawler Trophies
        	self.writeVInt(player.OwnedBrawlers[str(playerData["SelectedBrawlers"][0])]['HighestTrophies']) # Brawler Trophies for Rank
        	self.writeVInt(player.OwnedBrawlers[str(playerData["SelectedBrawlers"][0])]['PowerLevel']) # Brawler Level
        	self.writeVInt(3) # Player State
        	self.writeBoolean(memberData["Ready"]) # Ready
        	self.writeVInt(0) # Team
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	
        	self.writeString(playerData["Name"]) # Player Name
        	self.writeVInt(100)
        	self.writeVInt(28000000 + playerData["Thumbnail"]) # Player Thumbnail
        	self.writeVInt(43000000 + playerData["Namecolor"]) # Player Name Color
        	self.writeVInt(-1) # Player Gradient Name Color
        	self.writeDataReference(0, 0) # Starpower
        	self.writeDataReference(0, 0) # Gadget
        	self.writeDataReference(0, 0) # Gear
        	self.writeDataReference(0, 0) # Gear
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        
        self.writeVInt(len(teamData["Invites"])) # Invite Players
        for x in teamData["Invites"]:
        	memberData = teamData["Invites"][x]
        	playerData = json.loads(db_instance.getPlayerEntry([memberData["ID"][0], memberData["ID"][1]])[2])
        	self.writeLong(0, 1) # Unk
        	self.writeLong(memberData["ID"][0], memberData["ID"][1]) # PlayerID
        	self.writeString(playerData["Name"]) # Name
        	self.writeVInt(1) # Invite State
        self.writeVInt(0) # Team Join Request
        for x in range(0):
        	self.writeInt(1)
        	self.writeInt(1)
        self.writeVInt(0) # Bot Slots Disabled
        for x in range(0):
        	self.writeVInt(x+ 1)
        self.writeBoolean(True) #Text Chat Enabled
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0) # Modifiers
        for x in range(0):
        	self.writeVInt(1) # Modifier ID
        self.writeVInt(0)
        self.writeVInt(0)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24124

    def getMessageVersion(self):
        return self.messageVersion