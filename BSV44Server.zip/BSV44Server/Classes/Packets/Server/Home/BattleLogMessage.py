from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class BattleLogMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def encode(self, fields, player):
        self.writeBoolean(True)
        
        try:
        	player.Logs
        except KeyError:
        	player.Logs = []
        logs = player.Logs
        logs.sort(key = lambda x: x['Number'], reverse = True)
        if len(logs) >= 25:
        	self.writeVInt(25) # Count
        else:
        	self.writeVInt(len(logs)) # Count
        for x in logs:
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(99999)    # Time When Battle Log Entry Was Created
        	self.writeVInt(1)    # Battle Log Type (1 = Normal, 2 = Crash, 3 = Survived for <time>,4 = BigGame, 7 = Duels) 
        	self.writeVInt(x['Trophies'])    # Trophies Result
        	self.writeVInt(120)  # Battle Time
        	self.writeBoolean(False)   # Friendly
        	self.writeDataReference(15, x['MapID'][1]) # Map SCID
        	self.writeVInt(x['Result']) # Victory/Defeat/Draw
        	self.writeVInt(0)
        	self.writeVInt(0)
        	
        	self.writeInt(1)
        	self.writeInt(0)
        	
        	self.writeVInt(1)
        	self.writeBoolean(True)
        	self.writeVInt(0)
        	self.writeVInt(0) # Players Array
        	
        	self.writeVInt(0)
        	self.writeBoolean(False)
        	self.writeVInt(0)
        	self.writeBoolean(False)
        	self.writeVInt(0)
        	self.writeBoolean(False)
        	self.writeBoolean(False)
        	self.writeVLong(0, 1) # BattleLogID
        	self.writeBoolean(False)
        	self.writeVInt(x['ChallengeVariation']) # Challenge Variation
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	if logs.index(x) + 1 == 25:
        		break

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass
        
        

    def getMessageType(self):
        return 23458

    def getMessageVersion(self):
        return self.messageVersion