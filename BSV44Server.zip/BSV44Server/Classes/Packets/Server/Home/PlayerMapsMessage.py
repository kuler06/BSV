from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class PlayerMapsMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def encode(self, fields, player):
    	self.writeVInt(8)# Count

    	for i in [0, 2, 3, 5, 6, 9, 11, 20]:
    		self.writeVLong(0, int(i)) # Map ID
    		self.writeString(f"https://t.me/fightingbrawl") # Map Name
    		self.writeVInt(i) # Game Mode Variation
    		self.writeDataReference(54, 7) # Location Theme Data
    		self.writeCompressedString(b'M') # Compressed Map Data
    		self.writeVLong(player.ID[0], player.ID[1]) # Account ID
    		self.writeString(player.Name) # Avatar Name
    		self.writeVInt(1) # State
    		self.writeLong(1, 8) # Last Update Time Seconds Since Epoch
    		self.writeVInt(1) # Friendly Participant Count
    		self.writeVInt(0) # Friendly Signoff Count

    		self.writeVInt(1) # Likes
    		self.writeVInt(1) # Dislikes
    		self.writeVInt(5) # Battles
    	

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 22102

    def getMessageVersion(self):
        return self.messageVersion
