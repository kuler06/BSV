from io import BytesIO

from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
import Configuration
from Database.DatabaseHandler import DatabaseHandler
import json
import Configuration


OwnedBrawlersLatest = {
    0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    1: {'CardID': 4, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    2: {'CardID': 8, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    3: {'CardID': 12, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    4: {'CardID': 16, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    5: {'CardID': 20, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    6: {'CardID': 24, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    7: {'CardID': 28, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    8: {'CardID': 32, 'Skins': [435], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    9: {'CardID': 36, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    10: {'CardID': 40, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    11: {'CardID': 44, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    12: {'CardID': 48, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    13: {'CardID': 52, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    14: {'CardID': 56, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    15: {'CardID': 60, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    16: {'CardID': 64, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    17: {'CardID': 68, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    18: {'CardID': 72, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    19: {'CardID': 95, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    20: {'CardID': 100, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    21: {'CardID': 105, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    22: {'CardID': 110, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    23: {'CardID': 115, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    24: {'CardID': 120, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    25: {'CardID': 125, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    26: {'CardID': 130, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    27: {'CardID': 177, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    28: {'CardID': 182, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    29: {'CardID': 188, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    30: {'CardID': 194, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    31: {'CardID': 200, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    32: {'CardID': 206, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    34: {'CardID': 218, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    35: {'CardID': 224, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    36: {'CardID': 230, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    37: {'CardID': 236, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    38: {'CardID': 279, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    39: {'CardID': 296, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    40: {'CardID': 303, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    41: {'CardID': 320, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    42: {'CardID': 327, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    43: {'CardID': 334, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    44: {'CardID': 341, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    45: {'CardID': 358, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    46: {'CardID': 365, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    47: {'CardID': 372, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    48: {'CardID': 379, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    49: {'CardID': 386, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    50: {'CardID': 393, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    51: {'CardID': 410, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    52: {'CardID': 417, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    53: {'CardID': 427, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    54: {'CardID': 434, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    56: {'CardID': 448, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    57: {'CardID': 466, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    58: {'CardID': 474, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    59: {'CardID': 491, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2}
}


class BattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeLong(0, 1)
        self.writeLong(0, 1)
        self.writeVInt(fields["GameMode"]) # Battle End Game Mode
        self.writeVInt(fields["Rank"]) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVInt(fields["TokensGained"]) # Tokens Gained
        self.writeVInt(fields["TrophiesResult"]) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained
        self.writeVInt(0) # Doubled Tokens
        self.writeVInt(fields["DoubleTokenEvent"]) # Double Token Event
        self.writeVInt(0) # Token Doubler Remaining
        self.writeVInt(0) # Special Events Level Passed
        self.writeVInt(0) # Epic Win Power Play Points Gained
        self.writeVInt(fields["ChallengeWin"]) # Challenge Level Passed
        if fields["ChallengeReward"] != {}:
        	self.writeBoolean(True) # Challenge Reward Array
        	self.writeVInt(fields["ChallengeReward"]["Type"])
        	self.writeVInt(fields["ChallengeReward"]["Amount"])
        	self.writeDataReference(fields["ChallengeReward"]["Brawler"][0], fields["ChallengeReward"]["Brawler"][1])
        	self.writeVInt(fields["ChallengeReward"]["Extra"])
        else:
        	self.writeBoolean(False) # Challenge Reward Array
        self.writeVInt(0) # Challenge Reward Amount(Dont use)
        self.writeVInt(fields["ChallengeLosses"]) # Championship Losses Left
        self.writeBoolean(False) # Unk Bool
        self.writeVInt(fields["CoinShowEvent"]) # Coin Shower Event
        self.writeVInt(0) # Underdog Trophies
        self.writeVInt(0) # SD+ Win Trophies
        self.writeVInt(0) # SD+ Lose Trophies
        self.writeVInt(16) # Battle Result Type
        self.writeBoolean(False) # Unk
        self.writeBoolean(False) # Experience is Over
        self.writeBoolean(False) # Battle Tokens is Over
        self.writeBoolean(False) # Battle End State Off
        if fields["ChallengeVariation"] == -1:
        	self.writeBoolean(True) # Trophies State
        else:
        	self.writeBoolean(False) # Trophies State
        self.writeBoolean(False) # Battle End State is Over
        self.writeBoolean(False) # Power Play Battle End
        self.writeVInt(fields["ChallengeVariation"]) # Challenge Type
        if fields["ChallengeWin"] == Configuration.settings["ChallengeTotalWins"]:
        	self.writeBoolean(True) # Challenge passed
        else:
        	self.writeBoolean(False) # Challenge passed

        self.writeVInt(fields["HeroesCount"]) # Players In Battle End
        for heroEntry in fields["Heroes"]:
            self.writeBoolean(heroEntry["IsPlayer"])
            if fields["GameMode"] == 2:
            	self.writeBoolean(0)
            	self.writeBoolean(bool(heroEntry["Team"]))
            else:
            	self.writeBoolean(bool(heroEntry["Team"]))
            	self.writeBoolean(bool(heroEntry["Team"]))
            self.writeVInt(1)
            for i in range(1):
                self.writeDataReference(heroEntry["Brawler"]["ID"][0], heroEntry["Brawler"]["ID"][1])
            self.writeVInt(1)
            for i in range(1):
                if heroEntry["Brawler"]["SkinID"] != None:
                    self.writeDataReference(heroEntry["Brawler"]["SkinID"][0], heroEntry["Brawler"]["SkinID"][1])
                else:
                    self.writeDataReference(0)
            self.writeVInt(1)
            for i in range(1):
        	       	if heroEntry["IsPlayer"]:
        	       		self.writeVInt(fields["Trophies"]) # Brawler Trophies
        	       	else:
        	       		self.writeVInt(0)
            self.writeVInt(1)
            for i in range(1):
        	       	if heroEntry["IsPlayer"]:
        	       		for i,v in player.OwnedBrawlers.items():
        	       			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:
        	       				self.writeVInt(v["PowerLevel"]) # Brawler Power LVL
        	       	else:
        	       		self.writeVInt(1)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(heroEntry["IsPlayer"])
            if heroEntry["IsPlayer"]:
                self.writeLong(player.ID[0], player.ID[1])
            self.writeString(heroEntry["PlayerName"])
            self.writeVInt(100)
            if heroEntry["IsPlayer"]:
            	self.writeVInt(28000000 + fields["PlayerThumbnail"])
            	self.writeVInt(43000000 + fields["PlayerNamecolor"])
            	if fields["PlayerBPActivated"]:
            		self.writeVInt(46000000 + fields["PlayerNamecolor"])
            	else:
            		self.writeVInt(-1)
            else:
            	self.writeVInt(28000000)
            	self.writeVInt(43000000)
            	self.writeVInt(-1)
            if heroEntry["IsPlayer"]:
                self.writeBoolean(False) # Club

        
        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(2)

        self.writeVInt(1)
        self.writeVInt(fields["Trophies"]) # Brawler Trophies
        self.writeVInt(fields["HighestTrophies"]) # Brawler Trophies

        self.writeVInt(5)
        self.writeVInt(player.Experience)
        self.writeVInt(player.Experience)

        self.writeDataReference(28, 0)
        self.writeBoolean(False) # Play Again
        self.writeBoolean(False) # Logic Quests
        #self.writeVInt(1) # Quests Count
#        for i in range(1):
#        	[[self.writeVInt(0) # Unk
#        	self.writeVInt(0) # Unk
#        	self.writeVInt(1) # Mission Type
#        	self.writeVInt(1000) # Achieved Goal
#        	self.writeVInt(100000) # Quest Goal
#        	self.writeDataReference(16, 57) #Brawler
#        	self.writeVInt(-1)# Game Mode
#        	self.writeVInt(0) # Unk
#        	self.writeVInt(1) # Reward Type
#        	self.writeVInt(200) # Extra/Reward Amount
#        	self.writeDataReference(0, 0) # BrawlerID
#        	self.writeVInt(0) # Extra
#        	self.writeVInt(0) # Unk
#        	self.writeVInt(0) # Current LVL
#        	self.writeVInt(0) # Max LVL
#        	self.writeVInt(0) #Timer
#        	self.writeBoolean(False) # Seen
#        	self.writeBoolean(False)
#        	self.writeBoolean(False)
#        	self.writeVInt(0) # Unk
#        	self.writeVInt(0) # Unk
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # LogicRankedMatchRoundState
        for x in range(0):
        	self.writeVInt(0)
        	self.writeVInt(1)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeVInt(0)
        
        player.TrophiesGained += fields["TrophiesResult"]
        player.TokensGained += fields["TokensGained"] + fields["DoubleTokenEvent"]
        player.CoinsGained += fields["CoinShowEvent"]
        player.TokensGained += fields["RewardTokens"]
        player.CoinsGained += fields["RewardCoins"]
        try:
        	player.GemsGained
        except KeyError:
        	player.GemsGained = 0
        player.GemsGained += fields["RewardGems"]
        try:
        	player.StarPointsGained
        except KeyError:
        	player.StarPointsGained = 0
        player.StarPointsGained += fields["RewardStarPoints"]
        

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 23456

    def getMessageVersion(self):
        return self.messageVersion
