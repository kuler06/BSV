from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.BitStream import BitStream


import Configuration

from Classes.Packets.PiranhaMessage import PiranhaMessage


class VisionUpdateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 1

    def encode(self, fields, player):
        self.writeVInt(fields["Tick"]) # Ticks
        self.writeVInt(1) # Handler Input
        self.writeVInt(0) # Commands
        self.writeVInt(fields["Tick"]) # Viewers
        self.writeBoolean(False) # Live
        
        stream = BitStream()
        
        #stream.writePositiveInt(1000000 + 0, 21)
#        stream.writePositiveVInt(0, 4)
#        stream.writePositiveInt(20, 1)
#        stream.writeInt(-1, 4) # понос
#        
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(1, 1)
#        
#        stream.writePositiveInt(0, 5)
#        stream.writePositiveInt(0, 6)
#        stream.writePositiveInt(0, 5)
#        stream.writePositiveInt(0, 6)
#        
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writeBoolean(False)
#        
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(9999, 12)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        
#        for i in range(6):
#        	stream.writePositiveInt(0, 1)
#        	stream.writePositiveInt(0, 1)
#        
#        stream.writePositiveInt(0, 4) # unknown dudka
#        
#        # GameObjects start
#        stream.writePositiveInt(1, 8) # count
#        
#        # objects config start
#        stream.writePositiveInt(16, 5)
#        stream.writePositiveInt(0, 9) # id
#        # objects config end
#        
#        # IDs start
#        stream.writePositiveInt(0, 14)
#        # IDs end
#        
#        # player start
#        stream.writePositiveVInt(3177, 4) # x
#        stream.writePositiveVInt(1006, 4) # y
#        stream.writePositiveVInt(0, 3) #i
#        stream.writePositiveVInt(0, 4) # z
#        stream.writePositiveInt(10, 4)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 3)
#        stream.writePositiveInt(1, 1)
#        stream.writeInt(63, 6)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 2)
#        stream.writePositiveInt(3599, 13)
#        stream.writePositiveInt(3600, 13)
#        stream.writePVIntMax255OZ(10)
#        stream.writePVIntMax255OZ(0)
#        stream.writePositiveInt(1, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 4)
#        stream.writePositiveInt(0, 2)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 9)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        stream.writePositiveInt(0, 1)
#        
#        
#        stream.writePositiveInt(0, 5)
#        
#        stream.writePVIntMax255OZ(0)
#        stream.writePositiveInt(0, 1)
#        stream.writePVIntMax255OZ(0)
#        stream.writePositiveInt(3000, 12)
#        stream.writePVIntMax255OZ(0)
#        stream.writePositiveInt(0, 1)
#        stream.writePVIntMax255OZ(0)
#        # GameObjects end
#        
#        stream.writePositiveInt(0, 8) # unknown dudka
        
        self.writeBytes(stream.getBuff(), len(stream.getBuff()))


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24109

    def getMessageVersion(self):
        return self.messageVersion