from Classes.ByteStream import ByteStream
from Classes.Messaging import Messaging
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler, TeamDatabaseHandler
import random
import json


class TeamChatMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        pass

    def decode(self):
        fields = {}
        fields["Message"] = self.readString()
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        teamdb_instance = TeamDatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(calling_instance.player.TeamID[1])[0][1])
        
        LastMessageID = len(teamData["ChatData"])
        Role = int(teamData["Members"][str(playerData["ID"][1])]["Owner"])
        message = {
        'StreamType': 2,
        'StreamID': [0, LastMessageID + 1],
        'PlayerID': calling_instance.player.ID,
        'PlayerName': calling_instance.player.Name,
        'PlayerRole': Role,
        'Message': fields["Message"]
        }
        teamData["ChatData"].append(message)
        teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        allSockets = ClientsManager.GetAll()
        for x in teamData["Members"]:
        	if int(x) in allSockets:
        		fields["Socket"] = allSockets[int(x)]["Socket"]
        		Messaging.sendMessage(24131, fields, calling_instance.player)


    def getMessageType(self):
        return 14359


    def getMessageVersion(self):
        return self.messageVersion
