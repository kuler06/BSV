from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.BitStream import BitStream

class ClientInputMessage(PiranhaMessage):
    
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        stream = BitStream()
        fields = {}
        pomet = []
        stream.readPositiveInt(14)
        stream.readPositiveInt(10)
        stream.readPositiveInt(13)
        stream.readPositiveInt(10)
        stream.readPositiveInt(10)
        count = stream.readPositiveInt(5)
        for i in range(count):
        	pomet.append(self.ogo())
        print(pomet)
        
        if pomet != []:
        	ponos = pomet[0]
        	self.player.dudu = ponos["counter"]
        	#if ponos["id"] == 2:
#				self.player.battleX = ponos["x"]
#				self.player.battleY = ponos["y"]
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 10555

    def getMessageVersion(self):
        return self.messageVersion

    def ogo(self):
    	stream = BitStream()
    	sral = {}
    	sral["counter"] = stream.readPositiveInt(15)
    	sral["id"] = stream.readPositiveInt(4)
    	sral["x"] = stream.readInt(15)
    	sral["y"] = stream.readInt(15)
    	sral["AutoAim"] = stream.readBoolean()
    	if sral["id"] == 9:
    		sral["pinid"] = stream.readPositiveInt(3)
    	if sral["AutoAim"]:
    		sral["dude"] = stream.readBoolean()
    		if dude:
    			stream.readPositiveInt(14)
    	return sral