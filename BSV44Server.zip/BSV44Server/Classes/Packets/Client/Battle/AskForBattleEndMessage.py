from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
import json
import Configuration

OwnedBrawlersLatest = {
    0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    1: {'CardID': 4, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    2: {'CardID': 8, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    3: {'CardID': 12, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    4: {'CardID': 16, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    5: {'CardID': 20, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    6: {'CardID': 24, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    7: {'CardID': 28, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    8: {'CardID': 32, 'Skins': [435], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    9: {'CardID': 36, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    10: {'CardID': 40, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    11: {'CardID': 44, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    12: {'CardID': 48, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    13: {'CardID': 52, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    14: {'CardID': 56, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    15: {'CardID': 60, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    16: {'CardID': 64, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    17: {'CardID': 68, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    18: {'CardID': 72, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    19: {'CardID': 95, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    20: {'CardID': 100, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    21: {'CardID': 105, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    22: {'CardID': 110, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    23: {'CardID': 115, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    24: {'CardID': 120, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    25: {'CardID': 125, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    26: {'CardID': 130, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    27: {'CardID': 177, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    28: {'CardID': 182, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    29: {'CardID': 188, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    30: {'CardID': 194, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    31: {'CardID': 200, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    32: {'CardID': 206, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    34: {'CardID': 218, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    35: {'CardID': 224, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    36: {'CardID': 230, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    37: {'CardID': 236, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    38: {'CardID': 279, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    39: {'CardID': 296, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    40: {'CardID': 303, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    41: {'CardID': 320, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    42: {'CardID': 327, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    43: {'CardID': 334, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    44: {'CardID': 341, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    45: {'CardID': 358, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    46: {'CardID': 365, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    47: {'CardID': 372, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    48: {'CardID': 379, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    49: {'CardID': 386, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    50: {'CardID': 393, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    51: {'CardID': 410, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    52: {'CardID': 417, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    53: {'CardID': 427, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    54: {'CardID': 434, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    56: {'CardID': 448, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    57: {'CardID': 466, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    58: {'CardID': 474, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    59: {'CardID': 491, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2}
}


class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["ResultTeam"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]): fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference()}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString()})
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        PlayersTeams = []
        for heroEntry in fields["Heroes"]:
        	PlayersTeams.append(heroEntry["Team"])
        PlayerTeam = PlayersTeams[0]
        PlayerTeamMembers = 0
        for v in PlayersTeams:
        	if v == PlayerTeam:
        		PlayerTeamMembers += 1
        fields["PlayerThumbnail"] = player_data["Thumbnail"]
        fields["PlayerNamecolor"] = player_data["Namecolor"]
        try:
        	player_data["BPActivated"]
        except KeyError:
        	player_data["BPActivated"] = False
        fields["PlayerBPActivated"] = player_data["BPActivated"]
        if fields["MapID"][1] in Configuration.settings["ChallengeMaps"]:
        	fields["ChallengeVariation"] = Configuration.settings["ChallengeVariation"]
        else:
        	fields["ChallengeVariation"] = -1
        if fields["HeroesCount"] == 10 and PlayerTeamMembers == 2:
        	fields["GameMode"] = 5
        	if fields["Rank"] >= 3:
        		fields["Result"] = 1
        elif fields["HeroesCount"] == 10:
        	fields["GameMode"] = 2
        	if fields["Rank"] >= 5:
        		fields["Result"] = 1
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [27, 29, 39, 68]:
        	fields["GameMode"] = 3
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [57, 67, 133]:
        	fields["GameMode"] = 6
        elif fields["HeroesCount"] == 6 and fields["MapID"][1] in [21, 30, 65, 66, 119, 120]:
        	fields["GameMode"] = 4
        	if fields["ResultTeam"] != PlayerTeam:
        		if fields["Rank"] == 0:
        			fields["Rank"] = 1
        		elif fields["Rank"] == 1:
        			fields["Rank"] = 0
        		for heroEntry in fields["Heroes"]:
        			if heroEntry["Team"] == 0:
        				heroEntry["Team"] = 1
        			elif heroEntry["Team"] == 1:
        				heroEntry["Team"] = 0
        else:
        	fields["GameMode"] = 1
        	if fields["ResultTeam"] != PlayerTeam:
        		if fields["Rank"] == 0:
        			fields["Rank"] = 1
        		elif fields["Rank"] == 1:
        			fields["Rank"] = 0
        		for heroEntry in fields["Heroes"]:
        			if heroEntry["Team"] == 0:
        				heroEntry["Team"] = 1
        			elif heroEntry["Team"] == 1:
        				heroEntry["Team"] = 0
        for heroEntry in fields["Heroes"]:
        	if heroEntry["IsPlayer"]:
        		for i,v in player_data["OwnedBrawlers"].items():
        		  			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:
        		  				fields["Trophies"] = v["Trophies"]
        		  				fields["HighestTrophies"] = v["HighestTrophies"]
        		  				if fields["ChallengeVariation"] == -1:
        		  					if fields["Rank"] == 0:
        		  						v["Trophies"] += 8
        		  					if fields["Rank"] == 1:
        		  						v["Trophies"] -= 5
        		  					if v["Trophies"] > v["HighestTrophies"]:
        		  						v["HighestTrophies"] = v["Trophies"]
        fields["TokensGained"] = 0
        fields["TrophiesResult"] = 0
        fields["DoubleTokenEvent"] = 0
        fields["CoinShowEvent"] = 0
        fields["RewardTokens"] = 0
        fields["RewardCoins"] = 0
        fields["RewardGems"] = 0
        fields["RewardStarPoints"] = 0
        if fields["ChallengeVariation"] == -1:
        	if fields["Rank"] == 0:
        		fields["TokensGained"] = 20
        		fields["TrophiesResult"] = 8
        		player_data["Trophies"] += 8
        		if player_data["Trophies"] > player_data["HighestTrophies"]:
        			player_data["HighestTrophies"] = player_data["Trophies"]
        		if Configuration.settings["GoldRushEvent"]:
        			fields["CoinShowEvent"] = 20
        			player_data["Coins"] += 20
        			player_data["BPTokens"] += 20
        		elif Configuration.settings["DoubleTokenEvent"]:
        		   fields["DoubleTokenEvent"] = 20
        		   player_data["BPTokens"] += 40
        		else:
        			player_data["BPTokens"] += 20
        	if fields["Rank"] == 1:
        		fields["TokensGained"] = 10
        		fields["TrophiesResult"] = -5
        		player_data["Trophies"] -= 5
        		if Configuration.settings["GoldRushEvent"] == True:
        			fields["CoinShowEvent"] = 10
        			player_data["Coins"] += 10
        			player_data["BPTokens"] += 10
        		elif Configuration.settings["DoubleTokenEvent"] == True:
        			fields["DoubleTokenEvent"] = 10
        			player_data["BPTokens"] += 20
        		else:
        			player_data["BPTokens"] += 10
        	if fields["Rank"] == 2:
        		fields["TokensGained"] = 15
        		if Configuration.settings["GoldRushEvent"] == True:
        			fields["CoinShowEvent"] = 15
        			player_data["Coins"] += 15
        			player_data["BPTokens"] += 15
        		elif Configuration.settings["DoubleTokenEvent"] == True:
        			fields["DoubleTokenEvent"] = 15
        			player_data["BPTokens"] += 30
        		else:
        			player_data["BPTokens"] += 15
        else:
        	if fields["Rank"] == 0:
        		challenge = Configuration.settings["ChallengeLogicName"]
        		player_data["Challenges"][challenge]["Wins"] += 1
        	elif fields["Rank"] == 1:
        		challenge = Configuration.settings["ChallengeLogicName"]
        		player_data["Challenges"][challenge]["Defeates"] += 1
        	if fields["Rank"] == 0:
        		fields["TokensGained"] = 20
        		if Configuration.settings["GoldRushEvent"]:
        			fields["CoinShowEvent"] = 20
        			player_data["Coins"] += 20
        			player_data["BPTokens"] += 20
        		elif Configuration.settings["DoubleTokenEvent"]:
        		   fields["DoubleTokenEvent"] = 20
        		   player_data["BPTokens"] += 40
        		else:
        			player_data["BPTokens"] += 20
        	if fields["Rank"] == 1:
        		fields["TokensGained"] = 10
        		if Configuration.settings["GoldRushEvent"] == True:
        			fields["CoinShowEvent"] = 10
        			player_data["Coins"] += 10
        			player_data["BPTokens"] += 10
        		elif Configuration.settings["DoubleTokenEvent"] == True:
        			fields["DoubleTokenEvent"] = 10
        			player_data["BPTokens"] += 20
        		else:
        			player_data["BPTokens"] += 10
        	if fields["Rank"] == 2:
        		fields["TokensGained"] = 15
        		if Configuration.settings["GoldRushEvent"] == True:
        			fields["CoinShowEvent"] = 15
        			player_data["Coins"] += 15
        			player_data["BPTokens"] += 15
        		elif Configuration.settings["DoubleTokenEvent"] == True:
        			fields["DoubleTokenEvent"] = 15
        			player_data["BPTokens"] += 30
        		else:
        			player_data["BPTokens"] += 15
        try:
        	player_data["Logs"]
        except KeyError:
        	player_data["Logs"] = []
        fields["ChallengeReward"] = {}
        fields["ChallengeWin"] = 0
        fields["ChallengeLosses"] = 0
        if fields["ChallengeVariation"] == -1:
        	if fields["Rank"] == 0:
        		log = {'Trophies': 8, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"])}
        	if fields["Rank"] == 1:
        		log = {'Trophies': -5, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        	if fields["Rank"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        else:
        	if fields["Rank"] == 0:
        		log = {'Trophies': 0, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		try:
        		    player_data["Notifications"]
        		except KeyError:
        			player_data["Notifications"] = []
        		challenge = Configuration.settings["ChallengeLogicName"]
        		for x in Configuration.settings["ChallengeRewards"]:
        			if x["Win"] == player_data["Challenges"][challenge]["Wins"]:
        				if x["Type"] == 1 or x["Type"] == 16 or x["Type"] == 17 or x["Type"] == 28:
        					if x["Type"] == 1:
        						player_data["Coins"] += x["Amount"]
        						fields["RewardCoins"] += x["Amount"]
        					elif x["Type"] == 17:
        						player_data["StarPoints"] += x["Amount"]
        						try:
        							player_data["StarPointsGained"]
        						except KeyError:
        							player_data["StarPointsGained"] = 0 
        						fields["RewardStarPoints"] += x["Amount"]
        					elif x["Type"] == 16:
        						player_data["Gems"] += x["Amount"]
        						try:
        							player_data["GemsGained"]
        						except KeyError:
        							player_data["GemsGained"] = 0 
        						fields["RewardGems"] += x["Amount"]
        					elif x["Type"] == 28:
        						player_data["BPTokens"] += x["Amount"]
        						fields["RewardTokens"] += x["Amount"]
        				if x["Type"] == 19 or x["Type"] == 25 or x["Type"] == 4 or x["Type"] == 6 or x["Type"] == 14 or x["Type"] == 10:
        					notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        					player_data["Notifications"].append(notification)
        				fields["ChallengeWin"] = player_data["Challenges"][challenge]["Wins"]
        				fields["ChallengeReward"] = {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}
        		if player_data["Challenges"][challenge]["Wins"] == Configuration.settings["ChallengeTotalWins"]:
        			reward = Configuration.settings["ChallengeFinalReward"]
        			if reward["Type"] == 19 or reward["Type"] == 25 or reward["Type"] == 4 or reward["Type"] == 6 or reward["Type"] == 14 or reward["Type"] == 10:
        				notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": reward["Type"], "Amount": reward["Amount"], "Brawler": reward["Brawler"], "Extra": reward["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        				player_data["Notifications"].append(notification)
        	if fields["Rank"] == 1:
        		log = {'Trophies': 0, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		challenge = Configuration.settings["ChallengeLogicName"]
        		fields["ChallengeLosses"] = player_data["Challenges"][challenge]["Defeates"]
        	if fields["Rank"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        player_data['Logs'].append(log)
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(23456, fields, calling_instance.player)

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion
