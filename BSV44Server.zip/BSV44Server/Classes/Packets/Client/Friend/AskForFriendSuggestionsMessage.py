from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Packets.Server.Home.BattleLogMessage import BattleLogMessage
from Classes.Messaging import Messaging

from Classes.ByteStream import ByteStream


class AskForFriendSuggestionsMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def decode(self):
        fields = {}
        return fields

    def encode(self):
    	pass
    
    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(20199, fields, calling_instance.player)
        Messaging.sendMessage(20105, fields, calling_instance.player)

    def getMessageType(self):
        return 10599

    def getMessageVersion(self):
        return self.messageVersion