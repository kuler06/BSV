import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters
import random
import Configuration


class LogicViewInboxNotificationCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["NotificationIndex"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        player_data["delivery_items"] = {
        'Boxes': []
        }
        box = {
        'Type': 0,
        'Items': []
        }
        notifications = player_data["Notifications"]
        notifications.sort(key = lambda x: x["Number"], reverse = True)
        for x in notifications:
        	if notifications.index(x) == fields["NotificationIndex"]:
        		if x["Type"] == 72 or x["Type"] == 94:
        			if x["DataRef"][0] == 29:
        				RewardID = 9
        				for i,v in player_data["OwnedBrawlers"].items():
        					v["Skins"].append(x["DataRef"][1])
        			if x["DataRef"][0] == 28 or x["DataRef"][0] == 52:
        				RewardID = 11
        				if x["DataRef"][0] == 28:
        					player_data["OwnedThumbnails"].append(x["DataRef"][1])
        			item = {'Amount': 1, 'DataRef': x["DataRef"], 'RewardID': RewardID}
        			box['Type'] = 100
        			box['Items'].append(item)
        			player_data["delivery_items"]['Boxes'].append(box)
        			db_instance.updatePlayerData(player_data, calling_instance)
        			fields["Socket"] = calling_instance.client
        			fields["Command"] = {"ID": 203}
        			fields["PlayerID"] = calling_instance.player.ID
        			Messaging.sendMessage(24111, fields)
        		if x["Type"] == 63 or x["Type"] == 70:
        			if x["Reward"]["Type"] == 25:
        				RewardID = 11
        				DataRef = [28, x["Reward"]["Extra"]]
        				player_data["OwnedThumbnails"].append(x["Reward"]["Extra"])
        				item = {'Amount': 1, 'DataRef': DataRef, 'RewardID': RewardID}
        				box['Type'] = 100
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        			elif x["Reward"]["Type"] == 19:
        				RewardID = 11
        				DataRef = [52, x["Reward"]["Extra"]]
        				player_data["OwnedPins"].append(x["Reward"]["Extra"])
        				item = {'Amount': 1, 'DataRef': DataRef, 'RewardID': RewardID}
        				box['Type'] = 100
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        			elif x["Reward"]["Type"] == 4:
        				for i,v in player_data["OwnedBrawlers"].items():
        					v["Skins"].append(x["Reward"]["Extra"])
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				if str(x["Reward"]["Brawler"][1]) not in brawlers:
        					brawlerID = x["Reward"]["Brawler"][1]
        					DataRef = [16, brawlerID]
        					RewardID = 1
        					item = {'Amount': 1, 'DataRef': DataRef, 'RewardID': RewardID}
        					box['Type'] = 100
        					box['Items'].append(item)
        					player_data["delivery_items"]['Boxes'].append(box)
        					player_data["OwnedBrawlers"][brawlerID] = {'CardID': Cards.getBrawlerUnlockID(brawlerID), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        				RewardID = 9
        				DataRef = [29, x["Reward"]["Extra"]]
        				item = {'Amount': 1, 'DataRef': DataRef, 'RewardID': RewardID}
        				box['Type'] = 100
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        			elif x["Reward"]["Type"] == 6:
        				box['Type'] = 10
        				brawlers= list(player_data["OwnedBrawlers"].keys())
        				pp1= random.randint(9,69)
        				pp2 = random.randint(9,69)
        				pp3 = random.randint(9,69)
        				ppbr = random.randint(20, 54)
        				brawlerID1= random.choice(brawlers)
        				brawlerID2 = random.choice(brawlers)
        				brawlerID3 = random.choice(brawlers)
        				while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        					brawlerID2 = random.choice(brawlers)
        				while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        					brawlerID3 = random.choice(brawlers)
        				if len(brawlers) != len(Characters.getBrawlersID()):
        					brawlerID6 = random.randint(0, 59)
        					while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        						brawlerID6 = random.randint(0, 59)
        				player_data["delivery_items"]['Type'] = 10
        				if random.randint(0, 15) == 3 and len(brawlers) != len(Characters.getBrawlersID()):
        				    item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        				    box['Items'].append(item)
        				    player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        				elif random.randint(0, 9) == 2:
        				    item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        				    box['Items'].append(item)
        				else:
        				    gold = random.randint(7, 59)
        				    if random.randint(0, 10) == 7:
        				    	gems = random.randint(15, 30)
        				    elif random.randint(0, 5) == 2:
        				    	gems = random.randint(7, 19)
        				    else:
        				    	gems = random.randint(3, 11)
        				    item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        				    box['Items'].append(item)
        				    item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        				    box['Items'].append(item)
        				    item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        				    box['Items'].append(item)
        				    item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        				    box['Items'].append(item)
        				    for i,v in player_data["OwnedBrawlers"].items():
        				    		if i == str(brawlerID1):
        				    			v["PowerPoints"] += pp1
        				    for i,v in player_data["OwnedBrawlers"].items():
        				    		if i == str(brawlerID2):
        				    			v["PowerPoints"] += pp2
        				    for i,v in player_data["OwnedBrawlers"].items():
        				    		if i == str(brawlerID3):
        				    			v["PowerPoints"] += pp3
        				    if random.randint(0, 3) == 2:
        				    	 item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        				    	 box['Items'].append(item)
        				    	 player_data["Gems"] += gems
        				    player_data["Coins"] += gold
        				    player_data["delivery_items"]['Boxes'].append(box)
        			elif x["Reward"]["Type"] == 14:
        				brawlers= list(player_data["OwnedBrawlers"].keys())
        				pp1= random.randint(9,127)
        				pp2 = random.randint(9,127)
        				pp3 = random.randint(9,127)
        				ppbr = random.randint(20, 64)
        				brawlerID1= random.choice(brawlers)
        				brawlerID2 = random.choice(brawlers)
        				brawlerID3 = random.choice(brawlers)
        				while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        					brawlerID2 = random.choice(brawlers)
        				while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        					brawlerID3 = random.choice(brawlers)
        				if len(brawlers) != len(Characters.getBrawlersID()):
        					brawlerID6 = random.randint(0, 59)
        					while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        						brawlerID6 = random.randint(0, 59)
        				gold = random.randint(21, 134)
        				if random.randint(0, 10) == 7:
        					gems = random.randint(30, 90)
        				elif random.randint(0, 5) == 2:
        					gems = random.randint(20, 50)
        				else:
        					gems = random.randint(5, 30)
        				box['Type'] = 12
        				item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        				box['Items'].append(item)
        				item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        				box['Items'].append(item)
        				item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        				box['Items'].append(item)
        				item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        				box['Items'].append(item)
        				for i,v in player_data["OwnedBrawlers"].items():
        					if i == str(brawlerID1):
        						v["PowerPoints"] += pp1
        				for i,v in player_data["OwnedBrawlers"].items():
        					if i == str(brawlerID2):
        						v["PowerPoints"] += pp2
        				for i,v in player_data["OwnedBrawlers"].items():
        					if i == str(brawlerID3):
        						v["PowerPoints"] += pp3
        				if random.randint(0, 10) == 3:
        					if len(brawlers) != len(Characters.getBrawlersID()):
        						item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        						box['Items'].append(item)
        						player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        				else:
        				 	if random.randint(0, 6) == 2:
        				 		item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        				 		box['Items'].append(item)
        				if random.randint(0, 3) == 2:
        				    item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        				    box['Items'].append(item)
        				    player_data["Gems"] += gems
        				player_data["delivery_items"]['Boxes'].append(box)
        			elif x["Reward"]["Type"] == 10:
        			   brawlers= list(player_data["OwnedBrawlers"].keys())
        			   pp1= random.randint(9,127)
        			   pp2 = random.randint(9,127)
        			   pp3 = random.randint(9,127)
        			   pp4 = random.randint(9,127)
        			   pp5 = random.randint(9,127)
        			   ppbr = random.randint(75, 120)
        			   brawlerID1= random.choice(brawlers)
        			   brawlerID2 = random.choice(brawlers)
        			   brawlerID3 = random.choice(brawlers)
        			   brawlerID4 = random.choice(brawlers)
        			   brawlerID5 = random.choice(brawlers)
        			   while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        			   	brawlerID2 = random.choice(brawlers)
        			   while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        			   	brawlerID3 = random.choice(brawlers)
        			   if len(brawlers) >= 4:
        			   	while brawlerID4 == brawlerID1 or brawlerID4 == brawlerID2 or brawlerID4 == brawlerID3 or brawlerID4 == brawlerID5:
        			   		brawlerID4 = random.choice(brawlers)
        			   if len(brawlers) >= 5:
        			   	while brawlerID5 == brawlerID1 or brawlerID5 == brawlerID2 or brawlerID5 == brawlerID3 or brawlerID5 == brawlerID4:
        			   		brawlerID5 = random.choice(brawlers)
        			   if len(brawlers) != len(Characters.getBrawlersID()):
        			   	brawlerID6 = random.randint(0, 59)
        			   	while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        			   		brawlerID6 = random.randint(0, 59)
        			   gold = random.randint(53, 271)
        			   if random.randint(0, 10) == 7:
        			   	gems = random.randint(30, 90)
        			   elif random.randint(0, 5) == 2:
        			   	gems = random.randint(20, 50)
        			   else:
        			   	gems = random.randint(5, 30)
        			   box['Type'] = 11
        			   item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        			   box['Items'].append(item)
        			   item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        			   box['Items'].append(item)
        			   item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        			   box['Items'].append(item)
        			   item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        			   box['Items'].append(item)
        			   for i,v in player_data["OwnedBrawlers"].items():
        			   	if i == str(brawlerID1):
        			   		v["PowerPoints"] += pp1
        			   for i,v in player_data["OwnedBrawlers"].items():
        			   	if i == str(brawlerID2):
        			   		v["PowerPoints"] += pp2
        			   for i,v in player_data["OwnedBrawlers"].items():
        			   	if i == str(brawlerID3):
        			   		v["PowerPoints"] += pp3
        			   if len(brawlers) >= 4:
        			   	item = {'Amount': pp4, 'DataRef': [16, brawlerID4], 'RewardID': 6}
        			   	box['Items'].append(item)
        			   	for i,v in player_data["OwnedBrawlers"].items():
        			   		if i == str(brawlerID4):
        			   			v["PowerPoints"] += pp4
        			   if len(brawlers) >= 5:
        			   	item = {'Amount': pp5, 'DataRef': [16, brawlerID5], 'RewardID': 6}
        			   	box['Items'].append(item)
        			   	for i,v in player_data["OwnedBrawlers"].items():
        			   		if i == str(brawlerID5):
        			   			v["PowerPoints"] += pp5
        			   if random.randint(0, 5) == 3:
        			   	if len(brawlers) != len(Characters.getBrawlersID()):
        			   		item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        			   		box['Items'].append(item)
        			   		player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        			   else:
        			   	if random.randint(0, 3) == 2:
        			   		item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        			   		box['Items'].append(item)
        			   if random.randint(0, 3) == 2:
        			   	item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        			   	box['Items'].append(item)
        			   	player_data["Gems"] += gems
        			   player_data["Coins"] += gold
        			   player_data["delivery_items"]['Boxes'].append(box)
        			db_instance.updatePlayerData(player_data, calling_instance)
        			fields["Socket"] = calling_instance.client
        			fields["Command"] = {"ID": 203}
        			fields["PlayerID"] = calling_instance.player.ID
        			Messaging.sendMessage(24111, fields)
        		if x["Type"] == 64:
        			if x["RewardType"] == 1:
        				RewardID = 7
        				player_data["Coins"] += x["Amount"]
        			elif x["RewardType"] == 16:
        				RewardID = 8
        				player_data["Gems"] += x["Amount"]
        			elif x["RewardType"] == 17:
        				RewardID = 12
        				player_data["StarPoints"] += x["Amount"]
        			elif x["RewardType"] == 28:
        				player_data["BPTokens"] += x["Amount"]
        			if x["RewardType"] == 1 or x["RewardType"] == 16 or x["RewardType"] == 17:
        				Amount = x["Amount"]
        				item = {'Amount': Amount, 'DataRef': [0, 0], 'RewardID': RewardID}
        				box['Type'] = 100
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				db_instance.updatePlayerData(player_data, calling_instance)
        				fields["Socket"] = calling_instance.client
        				fields["Command"] = {"ID": 203}
        				fields["PlayerID"] = calling_instance.player.ID
        				Messaging.sendMessage(24111, fields)

        		if x["Type"] == 71:
        			if x["BPSeason"] == Configuration.settings["CurrentBPSeason"]:
        				player_data["BPTokens"] += x["Tokens"]

        		x["Readed"] = True
        		db_instance.updatePlayerData(player_data, calling_instance)


    def getCommandType(self):
        return 528
