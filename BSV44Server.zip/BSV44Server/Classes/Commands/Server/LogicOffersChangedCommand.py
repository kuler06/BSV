from Classes.Commands.LogicServerCommand import LogicServerCommand
from Static.StaticData import StaticData
from Database.DatabaseHandler import DatabaseHandler
import json


class LogicOffersChangedCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(fields["PlayerID"])[2])
        
        ownedSkins = []

        for brawlerInfo in player_data["OwnedBrawlers"].values():
            try:
                ownedSkins.extend(brawlerInfo["Skins"])
            except KeyError:
                continue
        
        ShopData = StaticData.ShopData

        self.writeVInt(len(ShopData["Offers"]) + len(player_data["DailyOffers"])) # Offers count

        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in ownedSkins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            			if str(reward["BrawlerID"][1]) not in list(player_data["OwnedBrawlers"].keys()):
            				midresult = False
            				for x in i["Rewards"]:
            					if x["ItemType"] == 3:
            						midresult = True
            				if midresult != True:
            					if len(i["Rewards"]) > 1:
            						results.append(True)
            					else:
            						result = True
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player_data["OwnedBrawlers"].keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player_data["OwnedPins"]:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player_data["OwnedThumbnails"]:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(1) # State
            self.writeVInt(0)
            if i["OfferID"] in player_data["PushasedOffers"] or checkAvailability() == True:
            	self.writeVInt(1) # Claim
            else:
            	self.writeVInt(int(i['Claim'])) # Claim
            self.writeVInt(ShopData["Offers"].index(i)) # Offer Index
            self.writeVInt(0)
            self.writeVInt(int(i["DailyOffer"]))
            self.writeVInt(i["OldPrice"])
            if "TID" in i["Text"]:
            	self.writeInt(1)
            elif i["Text"] == "None":
            	self.writeInt(2)
            else:
            	self.writeInt(0)
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeVInt(int(i["Processed"]))
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeVInt(int(i["OneTimeOffer"]))
            self.writeVInt(0) # Unk
            if i["BigOffer"] == True:
            	if i["ShopPanelLayouts"] != -1:
            		self.writeDataReference(69, i["ShopPanelLayouts"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            	if i["ShopStyleSets"] != -1:
            		self.writeDataReference(70, i["ShopStyleSets"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            else:
            	self.writeDataReference(0, 0) # For Big Offers
            	self.writeDataReference(0, 0) # For Big Offers
        
        for i in player_data["DailyOffers"]:
            self.writeVInt(1)  # RewardCount
            self.writeVInt(i["ItemType"]) # ItemType
            self.writeVInt(i["Amount"])
            if i["BrawlerID"][0] != 0:
                self.writeDataReference(i["BrawlerID"][0], i["BrawlerID"][1]) # CsvID
            else:
                self.writeDataReference(0)
            self.writeVInt(i["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(0) # Timer
            self.writeVInt(0) # State
            self.writeVInt(0)
            self.writeVInt(int(i["Claim"])) # Claim
            self.writeVInt(player_data["DailyOffers"].index(i) + 1 + len(ShopData["Offers"])) # Offer Index
            self.writeVInt(0)
            self.writeVInt(int(i["DailyOffer"]))
            self.writeVInt(i["OldPrice"])
            self.writeInt(0)
            self.writeString()
            self.writeVInt(0)
            self.writeString()
            self.writeVInt(-1)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeString()
            self.writeVInt(0)
            self.writeVInt(0) # Unk
            self.writeDataReference(0, 0) # For Big Offers
            self.writeDataReference(0, 0) # For Big Offers
        
        #self.writeVInt(1)  # RewardCount
#        for i in range(1):
#            self.writeVInt(16)  # ItemType
#            self.writeVInt(2000) # Amount
#            self.writeDataReference(0)  # BrawlerID
#            self.writeVInt(0) # SkinID

#        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
#        self.writeVInt(0) #Cost
#        self.writeVInt(172800) #Time
#        self.writeVInt(1) # State
#        self.writeVInt(0)
#        if -4 in player_data['PushasedOffers']:
#            self.writeVInt(1) # Claim
#        else:
#            self.writeVInt(0) # Claim
#        self.writeVInt(4 + len(ShopData["Offers"])) # Offer Index
#        self.writeVInt(0)
#        self.writeVInt(0) #Daily Offer
#        self.writeVInt(1) # Old price
#        self.writeInt(0)
#        self.writeString("Компенсация") # Text
#        self.writeVInt(0)
#        self.writeString("offer_deepsea") # Background
#        self.writeVInt(-1)
#        self.writeVInt(0) # This purchase is already being processed
#        self.writeVInt(1) # Type Benefit
#        self.writeVInt(100) # Benefit
#        self.writeString()
#        self.writeVInt(0) # One time offer
#        self.writeVInt(0) # unk
#        self.writeDataReference(0, 0) # For Big Offers
#        self.writeDataReference(0, 0) # For Big Offers
        
        
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        pass

    def getCommandType(self):
        return 211