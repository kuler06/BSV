
# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

BannedIPs = []

settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Maintance": False,
    "MaintanceTime": 0,
    "UpdateURL": "https://t.me/fightingbrawl/313",
    "Theme": 0,
    "SkinPack": 18,
    "DoubleTokenEvent": True,
    "GoldRushEvent": False,
    "CurrentBPSeason": 12,
    "MysteryModeEnabled": False,
    "MysteryModeModifiersEnabled": False,
    "MysteryModeMaps": [32, 45, 93, 105, 109, 154, 166, 224, 272],
    "MysteryModeName": "Solo Showdown and Modifiers",
    "ChallengeEnabled": True,
    "ChallengeLives": 4,
    "ChallengeLogicName": "badrandoms_challenge",
    "ChallengeVariation": 7,
    "ChallengeName": "Bad Randoms Challenge",
    "ChallengeStages": 3,
    "ChallengeTotalWins": 9,
    "ChallengeMaps": [4, 479, 12, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeMapsWins": [3, 3, 3, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeFinalReward": {"Type": 25, "Amount": 1, "Brawler": [0, 0], "Extra": 125},
    "ChallengeRewards": [{"Win": 1,"Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 2, "Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 3, "Type": 6, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 4, "Type": 28, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 5, "Type": 28, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 6, "Type": 14, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 7, "Type": 17, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 8, "Type": 17, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 9, "Type": 10, "Amount": 1, "Brawler": [0, 0], "Extra": 0}],
    "Proxy": False,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 44
}
