from Classes.Packets.PiranhaMessage import PiranhaMessage


import Configuration

from Classes.Packets.PiranhaMessage import PiranhaMessage


class VisionUpdateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 1

    def encode(self, fields, player):
        self.writeVInt(1) # Ticks
        self.writeVInt(0) # Handler Input
        self.writeVInt(0) # Commands
        self.writeVInt(0) # Viewers
        self.writeBoolean(False) # Live
        self.writeBoolean(False)
        #BitStream.getByteArray()
        #BitStream.getLength()


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24109

    def getMessageVersion(self):
        return self.messageVersion