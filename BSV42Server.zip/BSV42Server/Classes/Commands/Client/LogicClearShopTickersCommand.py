import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random
from Classes.Packets.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage


class LogicClearShopTickersCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["Reason"] = calling_instance.readVInt()
        fields["Reason"] = calling_instance.readVInt()
        fields["OfferID"] = calling_instance.readVInt()
        fields["Unk"] = calling_instance.readVInt()
        return fields

    def execute(self, calling_instance, fields):
        pass


    def getCommandType(self):
        return 515