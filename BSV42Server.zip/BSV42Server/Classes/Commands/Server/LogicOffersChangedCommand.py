from Classes.Commands.LogicServerCommand import LogicServerCommand
from Static.StaticData import StaticData
from Database.DatabaseHandler import DatabaseHandler
import json


class LogicOffersChangedCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(fields["PlayerID"])[2])
        
        ShopData = StaticData.ShopData
        
        self.writeVInt(4 + len(ShopData["Offers"])) # Offers count

        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(6)  # ItemType
            self.writeVInt(0) # Amount
            self.writeDataReference(0)  # BrawlerID
            self.writeVInt(0) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(1) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(1) # State
        self.writeVInt(0)
        self.writeBoolean(False) # Claim
        self.writeVInt(0) # Offer Index
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(1) # Old price
        self.writeInt(0)
        self.writeString("Unlock all brawlers") # Text
        self.writeBoolean(False)
        self.writeString("offer_stuntshow") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(100) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # unk
        
        self.writeVInt(2)  # RewardCount
        for i in range(1):
            self.writeVInt(1)  # ItemType
            self.writeVInt(1000) # Amount
            self.writeDataReference(0)  # CsvID
            self.writeVInt(0) # SkinID
        for i in range(1):
            self.writeVInt(16)  # ItemType
            self.writeVInt(250) # Amount
            self.writeDataReference(0)  # BrawlerID
            self.writeVInt(0) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(0) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(1) # State
        self.writeVInt(0)
        self.writeBoolean(False) # Claim
        self.writeVInt(1) # Offer Index
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(549) # Old price
        self.writeInt(0)
        self.writeString("Gift🤑") # Text
        self.writeBoolean(False)
        self.writeString("offer_stuntshow") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(2) # Type Benefit
        self.writeVInt(300) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Unk
        
        self.writeVInt(3)  # RewardCount
        for i in range(1):
            self.writeVInt(4)  # ItemType
            self.writeVInt(0) # Amount
            self.writeDataReference(16, 1)  # BrawlerID
            self.writeVInt(376) # SkinID
        for i in range(1):
            self.writeVInt(19)  # ItemType
            self.writeVInt(250) # Amount
            self.writeDataReference(0)  # BrawlerID
            self.writeVInt(272) # SkinID
        for i in range(1):
            self.writeVInt(9)  # ItemType
            self.writeVInt(1000) # Amount
            self.writeDataReference(0)  # BrawlerID
            self.writeVInt(1000) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(109) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(1) # State
        self.writeVInt(0)
        self.writeBoolean(False) # Claim
        self.writeVInt(2) # Offer Index
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(159) # Old price
        self.writeInt(0)
        self.writeString("Special Offer") # Text
        self.writeBoolean(False)
        self.writeString("offer_stuntshow") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(2) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Unk

        for i in ShopData["Offers"]:
            self.writeVInt(len(i["Rewards"]))  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(1) # State
            self.writeVInt(0)
            self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i) + 3) # Offer Index
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            if "TID" in i["Text"]:
            	self.writeInt(1)
            elif i["Text"] == "None":
            	self.writeInt(2)
            else:
            	self.writeInt(0)
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False) # Unk
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(16)  # ItemType
            self.writeVInt(2000) # Amount
            self.writeDataReference(0)  # BrawlerID
            self.writeVInt(0) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(0) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(1) # State
        self.writeVInt(0)
        self.writeBoolean(False) # Claim
        self.writeVInt(4 + len(ShopData["Offers"])) # Offer Index
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(1) # Old price
        self.writeInt(0)
        self.writeString("Компенсация") # Text
        self.writeBoolean(False)
        self.writeString("offer_deepsea") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(100) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # unk
        
        
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        pass

    def getCommandType(self):
        return 211