
# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

settings = {
    "DisableNagle": True,
    "BannedIPs": [],
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Theme": 39,
    "SkinPack": 14,
    "DoubleTokenEvent": True,
    "GoldRushEvent": False,
    "CurrentBPSeason": 10,
    "ChallengeLives": 4,
    "ChallengeLogicName": "solo_challenge",
    "ChallengeVariation": 7,
    "ChallengeName": "Solo Challenge",
    "ChallengeStages": 5,
    "ChallengeTotalWins": 10,
    "ChallengeMaps": [13, 123, 125, 101, 257, 0, 0, 0, 0, 0],
    "ChallengeMapsWins": [2, 2, 2, 2, 2, 0, 0, 0, 0, 0],
    "ChallengeFinalReward": {"Type": 19, "Amount": 1, "Brawler": [0, 0], "Extra": 747},
    "ChallengeRewards": [{"Win": 1,"Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 2, "Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 3, "Type": 6, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 4, "Type": 6, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 5, "Type": 17, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 6, "Type": 17, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 7, "Type": 28, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 8, "Type": 28, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 9, "Type": 14, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 10, "Type": 14, "Amount": 1, "Brawler": [0, 0], "Extra": 0}],
    "Maintance": False,
    "MaintanceTime": 300,
    "UpdateURL": "https://t.me/fightingbrawl/269",
    "Proxy": False,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 42
}
